from PIL import Image
#import
image = Image.open('2_Sphaer 2021_1_2021_06_03-11-22-54-894.PNG')
#flip
image_transpose = image.transpose(Image.Transpose.ROTATE_90)
#rotate
image_rotate = image = image.rotate(45, expand=False,center = (0,0))
#crop
image_crop = image.crop((800,600,1600,1600))
#resize
image_resized = image.resize((1000,600))
#apply multiple
combined_image = image.transpose(Image.Transpose.ROTATE_90).resize((2000,1500)).rotate(10)

combined_image.show()