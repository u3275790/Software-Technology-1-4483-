from PIL import Image

image = Image.open("1_Limniu 2021_1_2021_06_02-13-08-37-958.PNG")

#image.show()

#analyse image
print(image.size)
print(image.filename)
print(image.format)


image.show()
#flip image
#image = image.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
#image = image.transpose(Image.Transpose.FLIP_TOP_BOTTOM)

#img_rotated = image.rotate(30)
#img_rotated.save (r'/Users/ishmam/Downloads/Week_4_Lab_Activities/pillow_practice\img_rotated.png','PNG')

