from PIL import Image, ImageEnhance

#import
image = Image.open('2_Sphaer 2021_1_2021_06_03-11-22-54-894.PNG')
# create enchancer

vibrance_enhancer = ImageEnhance.Color(image)
contrast_enhancer = ImageEnhance.Contrast(image)
brightness_enhancer = ImageEnhance.Brightness(image)
sharpness_enhancer = ImageEnhance.Sharpness(image)

#apply
enhanced_image = sharpness_enhancer.enhance(1.5)

#show

image.show()
enhanced_image.show()